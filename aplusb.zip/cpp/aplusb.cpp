#include "aplusb.h"

std::vector<int> smallest_sums(int N, std::vector<int> A, std::vector<int> B) {
	return {};
}
