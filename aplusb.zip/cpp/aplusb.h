#include <vector>

std::vector<int> smallest_sums(int N, std::vector<int> A, std::vector<int> B);
