#include "coreputer.h"

std::vector<int> malfunctioning_cores(int N) {
	return {};
}
