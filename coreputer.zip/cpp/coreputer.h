#include <vector>

std::vector<int> malfunctioning_cores(int N);

int run_diagnostic(std::vector<int> T);
